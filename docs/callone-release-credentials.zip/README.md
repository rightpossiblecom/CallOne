# CallOne Release Credentials

- **Keystore Password:** callone123
- **Key Password:** callone123
- **Key Alias:** callone

⚠️ **CRITICAL: Back up these files! Losing the keystore means you cannot update the app on the Play Store!**
